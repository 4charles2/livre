#! /bin/sh
cat $0
