#! /bin/sh

ma_variable=2008
echo $ma_variable
