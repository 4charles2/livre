#! /bin/sh
echo Cette ligne va sur la sortie standard
./echo_stderr Ce message est envoy� sur la sortie d\'erreur
