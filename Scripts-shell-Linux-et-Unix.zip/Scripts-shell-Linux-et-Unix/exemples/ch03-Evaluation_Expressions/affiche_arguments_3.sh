#! /bin/sh

while [ -n "$1" ] ; do
  echo $1
  shift
done
