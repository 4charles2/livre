#! /bin/sh

./affiche_arguments_5.sh $*
