#! /bin/sh
ls -l $*
