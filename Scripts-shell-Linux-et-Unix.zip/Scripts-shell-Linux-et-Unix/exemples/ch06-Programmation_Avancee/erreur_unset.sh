#! /bin/sh

  set -o nounset

  if [ -z "$Chaine" ] ; then
	echo "La cha�ne est vide"
  fi

